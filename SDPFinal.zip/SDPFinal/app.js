// Singleton Pattern
const TaskManager = (() => {
    let instance;
    function createInstance() {
        const tasks = [];
        return {
            addTask: function (task) {
                tasks.push(task);
                TaskManager.notifyObservers();
            },
            getTasks: function () {
                return tasks;
            },
        };
    }

    return {
        getInstance: function () {
            if (!instance) {
                instance = createInstance();
            }
            return instance;
        },
        observers: [],
        addObserver: function (observer) {
            this.observers.push(observer);
        },
        notifyObservers: function () {
            for (const observer of this.observers) {
                observer.update();
            }
        },
    };
})();

// Observer Pattern
const TaskListObserver = {
    update: function () {
        const taskList = document.getElementById('taskList');
        const tasks = TaskManager.getInstance().getTasks();
        taskList.innerHTML = '';
        tasks.forEach(task => {
            const listItem = document.createElement('li');
            listItem.textContent = task.title;
            taskList.appendChild(listItem);
        });
    },
};

TaskManager.addObserver(TaskListObserver);
const TaskFactory = {
    createTask: function (title, description, priorityStrategy) {
        const task = {
            title,
            description,
        };
        task.priority = priorityStrategy.getPriority();
        task.decorate = function (decorator) {
            decorator.decorate(task);
        };
        return task;
    },
};

// Strategy Pattern
const PriorityStrategy = {
    getPriority: function () {
        return 'High';
    },
};

// Decorator Pattern
const DueDateDecorator = {
    decorate: function (task) {
        task.dueDate = new Date(); 
    },
};

const AttachmentDecorator = {
    decorate: function (task) {
        task.attachments = [];
    },
};

// Modal View Control Pattern:
const TaskController = {
    modal: null,

    init: function () {
        this.modal = document.getElementById('yourModalId');
        this.setupEventListeners();
    },

    setupEventListeners: function () {
        const closeButton = this.modal.querySelector('.close-button');
        closeButton.addEventListener('click', this.closeModal.bind(this));
    },

    openModal: function () {
        this.modal.style.display = 'block';
    },

    closeModal: function () {
        this.modal.style.display = 'none';
    }
};

document.getElementById('taskForm').addEventListener('submit', function (event) {
    event.preventDefault();

    const title = document.getElementById('taskTitle').value;
    const description = document.getElementById('taskDescription').value;

    // Factory Method Pattern
    const task = TaskFactory.createTask(title, description, PriorityStrategy);

    // Decorator Pattern
    task.decorate(DueDateDecorator);
    task.decorate(AttachmentDecorator);

    // Singleton Pattern
    TaskManager.getInstance().addTask(task);

    document.getElementById('taskTitle').value = '';
    document.getElementById('taskDescription').value = '';
});

// MVC Pattern
TaskController.init();
